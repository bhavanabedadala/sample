//
//  ViewController.h
//  Chat
//
//  Created by Vishnu on 16/10/18.
//  Copyright © 2018 Bhavana. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *leftlbl;
@property (weak, nonatomic) IBOutlet UILabel *rightlbl;
@property (weak, nonatomic) IBOutlet UITextView *textfield;
@property (weak, nonatomic) IBOutlet UIButton *sendButton;
@property (strong, nonatomic) NSString * chatText;

@end

