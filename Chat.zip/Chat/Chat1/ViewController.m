//
//  ViewController.m
//  Chat
//
//  Created by Vishnu on 16/10/18.
//  Copyright © 2018 Bhavana. All rights reserved.
//

#import "ViewController.h"
#import <ApiAI/ApiAI.h>

@interface ViewController ()<UITextViewDelegate>
{
    
    UIImageView *animationImageView;
    UIImageView *imgView;
    
}
@end

@implementation ViewController
@synthesize chatText;
- (void)viewDidLoad {
    [super viewDidLoad];
    _textfield.delegate = self;
    [self stop];
    _rightlbl.text=@"Hai this is the test sample of chat bot";
    chatText = _rightlbl.text;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showMonth:) name:@"loginComplete" object:nil];
    
    [imgView removeFromSuperview];
    NSArray *imageNames = @[@"AW313096_18-1 (dragged).tiff", @"AW313096_18-2 (dragged).tiff",@"AW313096_18-3 (dragged).tiff", @"AW313096_18-4 (dragged).tiff",@"AW313096_18-5 (dragged).tiff", @"AW313096_18-6 (dragged).tiff",@"AW313096_18-7 (dragged).tiff", @"AW313096_18-8 (dragged).tiff",@"AW313096_18-9 (dragged).tiff", @"AW313096_18-10 (dragged).tiff",@"AW313096_18-11 (dragged).tiff", @"AW313096_18-12 (dragged).tiff",@"AW313096_18-13 (dragged).tiff", @"AW313096_18-14 (dragged).tiff",@"AW313096_18-15 (dragged).tiff", @"AW313096_18-16 (dragged).tiff"];
    
    NSMutableArray *images = [[NSMutableArray alloc] init];
    for (int i = 0; i < imageNames.count; i++)
    {
        [images addObject:[UIImage imageNamed:[imageNames objectAtIndex:i]]];
    }
    
    // Normal Animation
//    animationImageView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 120, 250, 300)];
    animationImageView = [[UIImageView alloc] initWithFrame:_imageView.frame];
    animationImageView.animationImages = images;
    animationImageView.animationDuration = 1;
    
    [self.view addSubview:animationImageView];
    [animationImageView startAnimating];
}
- (void)textViewDidEndEditing:(UITextView *)textView{
    _rightlbl.text = _textfield.text;
     [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(sending) userInfo:nil repeats:NO];
}
- (void)showMonth:(NSNotification *)note {
    //NSString *Month = [[NSUserDefaults standardUserDefaults] objectForKey:@"Month"];
    NSLog(@"******");
}
-(void)showGif{
    [imgView removeFromSuperview];
    
    NSArray *imageNames = @[@"AW313096_18-1 (dragged).tiff", @"AW313096_18-2 (dragged).tiff",@"AW313096_18-3 (dragged).tiff", @"AW313096_18-4 (dragged).tiff",@"AW313096_18-5 (dragged).tiff", @"AW313096_18-6 (dragged).tiff",@"AW313096_18-7 (dragged).tiff", @"AW313096_18-8 (dragged).tiff",@"AW313096_18-9 (dragged).tiff", @"AW313096_18-10 (dragged).tiff",@"AW313096_18-11 (dragged).tiff", @"AW313096_18-12 (dragged).tiff",@"AW313096_18-13 (dragged).tiff", @"AW313096_18-14 (dragged).tiff",@"AW313096_18-15 (dragged).tiff", @"AW313096_18-16 (dragged).tiff"];
    
    NSMutableArray *images = [[NSMutableArray alloc] init];
    for (int i = 0; i < imageNames.count; i++)
    {
        [images addObject:[UIImage imageNamed:[imageNames objectAtIndex:i]]];
    }
    
    // Normal Animation
    //    animationImageView = [[UIImageView alloc] initWithFrame:CGRectMake(100, 120, 250, 300)];
    animationImageView = [[UIImageView alloc] initWithFrame:_imageView.frame];
    animationImageView.animationImages = images;
    animationImageView.animationDuration = 1;
    
    [self.view addSubview:animationImageView];
    [animationImageView startAnimating];
}
-(void)sending{
    [self sendButtonClicked:nil];
}
- (IBAction)sendButtonClicked:(id)sender {
    if(_leftlbl.text == nil){
        
    }
    else{
        ApiAI *apiai = [ApiAI sharedApiAI];
        
        AITextRequest *request = [apiai textRequest];
        request.query = chatText;
        AIResponse *response;
        
        __weak typeof(self) selfWeak = self;
        
        [request setMappedCompletionBlockSuccess:^(AIRequest *request, AIResponse *response) {
            __strong typeof(selfWeak) selfStrong = selfWeak;
            
#if 0
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:response.status.errorType
                                                                message:response.result.fulfillment.speech
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
            [alertView show];
#endif
              [[NSNotificationCenter defaultCenter] postNotificationName:@"loginComplete" object:[NSString stringWithFormat:@"%@",response.result.fulfillment.speech]];
            
            _leftlbl.text = response.result.fulfillment.speech;
         NSLog(@"result is :%@", response.result.fulfillment.speech);
            
        } failure:^(AIRequest *request, NSError *error) {
            __strong typeof(selfWeak) selfStrong = selfWeak;
            
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                                message:[error localizedDescription]
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
            [alertView show];
            
        }];
        
        [apiai enqueue:request];
  
    }
    
}
-(void)stop{
    [animationImageView stopAnimating];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

