//
//  ViewController.swift
//  Swiftbasic
//
//  Created by Vishnu on 24/07/18.
//  Copyright © 2018 Bhavana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let minutes = 60
        for tickMark in 0..<minutes {
           
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
}

